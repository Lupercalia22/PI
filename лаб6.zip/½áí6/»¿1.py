def num(p):
    def N(x):
        return p + x
    return N

p = 8
x = 10
print(num(p)(x))
