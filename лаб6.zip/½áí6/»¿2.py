def f1(p):
    return p * 3
def f2 (x):
    return x ** x

x = 5
p = f1(f2(x))
print(p)
x = 3
p = f1(f2(x))
print(p)
